// Select all input elements for validation
const name = document.getElementById("name");
const Age = document.getElementById("age");
const email = document.getElementById("email");
const password = document.getElementById("password");
const phoneNumber = document.getElementById("phoneNumber");
const gender = document.registration;
const country = document.getElementById("Country");


// function for form validation
function formValidation() {
  
  // checking name length
  if (name.value.length < 2 || name.value.length > 20) {
    alert("Name length should be more than 2 and less than 21");
    name.focus();
    return false;
  }

  // checking age

  if ( !( Age.value >=18  && Age.value<=60 ) ){

    alert("The age must be between 18 and 60 years old");
    Age.focus();
    return false;
}

  // checking email

let y = /^([a-z0-9_\.\+-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
  
    if (email.value.match(y) === null || email.value.length === 0)
{
    alert("Please enter a valid email!");
    email.focus();
    return false;
  }
  // checking password
  if (!password.value.match(/^.{5,15}$/)) {
    alert("Password length must be between 5-15 characters!");
    password.focus();
    return false;
  }
  // checking phone number
  if (!phoneNumber.value.match(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im)) {
    alert("Add a valid phone number");
    phoneNumber.focus();
    return false;
  }
  // checking gender
  if (gender.gender.value === "") {
    alert("Please select your gender!");
    return false;
  }
  // checking country
  if (country.value === "") {
    alert("Please select your country!")
    return false;
  }

}